package main

import (
	"fmt"
	"bufio"
	"os"
	"strings"
)

// define the struct
type Name struct {
	fname string
	lname string
}

func main() {
	// define the slice of structs
	slNames := make([]Name, 0)

	// instructions to run the code.
	fmt.Println("----  INFO  ------")
	fmt.Println("Please place the `file.txt` in the path where the `go run main.go` command will be triggerred from the CLI.")
	fmt.Println("----x  END  x------")
	fmt.Println()

	// take the file name as input from user
	var v string
	reader := bufio.NewReader(os.Stdin)
	fmt.Println("Enter name of the file > ")
	text, _ := reader.ReadString('\n')
	v = strings.TrimSpace(text)

	// read the file
	readFile, err := os.Open(v)
	if err != nil {
		fmt.Println("unable to read file. Check the path. Filenames are case sensitive.\nErr ::  ", err)
		return
	}

	// read contents of the file line by line
	fileScanner := bufio.NewScanner(readFile)
	fileScanner.Split(bufio.ScanLines)
	for fileScanner.Scan() {
		line := fileScanner.Text()
		fmt.Print(". ")
		namesFromLine := strings.Split(line, " ")
		name := Name{
			fname: getMaxSizeName(namesFromLine[0]),
			lname: getMaxSizeName(namesFromLine[0]),
		}
		slNames = append(slNames, name)

	}

	readFile.Close()
	fmt.Println("succesfully read the the file.")
	fmt.Println("Here are the contents of the file : ")

	//iterate over the slice of struct and print the names
	for _, item := range slNames {
		fmt.Printf("Fname: %s  Lname: %s\n", item.fname, item.lname)
	}
}

// function to return a maximum of 20 characters from input file
func getMaxSizeName(v string) string {
	if len(v) > 20 {
		return v[:20]
	}
	return v
}