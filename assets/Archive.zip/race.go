package main

import (
	"context"
	"fmt"

	"golang.org/x/sync/errgroup"
)

func main() {
	ctx := context.Background()
	g, ctx := errgroup.WithContext(ctx)
	/**
		I have written 2 anonymous go routines that are working in the
		main thread and trying to change the value of a predeclared int value x.
	**/

	// initializing x as 0 before calling goroutines.
	var x = 0

	//I am using 2 int channels to hold the values returned by the goroutines.
	ch1 := make(chan int)
	ch2 := make(chan int)

	/**
		Here a race condition occurs as x is assigned a value
		before the go-routines can finish executing, hence the
		value in the below println statement for x will not be 1
	**/
	g.Go(func() error {
		defer close(ch1)
		fmt.Println("CH1 | Working with x as ", x)
		x += 9
		select {
		case <-ctx.Done():
			return ctx.Err()
		case ch1 <- (x):
		}
		return nil
	})

	/**
		Here a race condition occurs as x is assigned a value
		before the go-routines can finish executing, hence the
		value in the below println statement for x will not be 1
	**/
	x = 1 // Assigning the value 1 to x to show the race condition

	g.Go(func() error {
		defer close(ch2)
		fmt.Println("CH2 | Working with x as ", x)
		x += 10
		select {
		case <-ctx.Done():
			return ctx.Err()
		case ch2 <- (x):
		}
		return nil
	})

	/***
	Value of x in the belwo statement will be 20 instead of 1 as assigned above
	***/
	fmt.Printf("x:= %d\tch1Int:= %d\tch2Int:= %d", x, <-ch1, <-ch2)
}
