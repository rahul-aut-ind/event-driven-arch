package main

import (
	"fmt"
	"bufio"
	"encoding/json"
	"os"
	"strings"
)

func main() {
	var v string
	jMap := make(map[string]string)

	reader := bufio.NewReader(os.Stdin)
	fmt.Print("Enter a name > \n")
	text, _ := reader.ReadString('\n')
	v = strings.TrimSpace(text)

	if v == "" {
		fmt.Println("You did not enter anything. Try again!!")
		return
	}
	jMap["name"] = v

	fmt.Print("Enter an address > \n")
	text, _ = reader.ReadString('\n')
	v = strings.TrimSpace(text)

	if v == "" {
		fmt.Println("You did not enter anything. Try again!!")
		return
	}
	jMap["address"] = v

	fmt.Println("----------------------------------")

	js, err := json.Marshal(jMap)
	if err != nil {
		fmt.Println("error marshalling ", err)
	}
	//print the print the JSON object in string format
	fmt.Println(string(js))

	// fmt.Println("----------------------------------")
	// print the print the JSON object as bytearray
	// fmt.Println(js)
}
