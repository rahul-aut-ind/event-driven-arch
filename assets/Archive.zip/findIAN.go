package main

import (
	"fmt"
	"strings"
)

func main() {
	var input string
	fmt.Print("Please enter any input here >> ")
	fmt.Scan(&input)

	switch{
	case strings.ContainsAny(strings.ToLower(input),"ian"):
		fmt.Println("Found!")
	default:
		fmt.Println("Not Found!")
	}
}
