package main

import (
	"fmt"
	"sort"
	"strconv"
	"strings"
)

func main() {
	var v, cont string
	enterValue := true

	sl := make([]int, 0)

	for {
		fmt.Println("Enter a number> ")
		fmt.Scan(&v)

		iInput, err := strconv.ParseInt(v, 10, 64)
		if err != nil {
			fmt.Println("You have entered an improper Number. Try again!!")
			continue
		}
		sl = append(sl, int(iInput))

		fmt.Print("do you want to enter another number (Y/N)? > ")
		fmt.Scan(&cont)
		enterValue = !strings.ContainsAny(cont, "Nn")
		if !enterValue {
			break
		}
	}
	fmt.Println("----------------------------------")

	// sorting the int slice
	sort.Ints(sl)

	fmt.Println("Sorted Slice of integers entered is :: ")
	for _, v := range sl {
		fmt.Print(v, " ")
	}
	fmt.Println("\n----------------------------------")
}
