package main

import (
	"fmt"
	"sort"
	"strconv"
	"strings"
	"sync"
)

func main() {
	/**********
	Write a program to sort an array of integers.
	The program should partition the array into 4 parts,
	each of which is sorted by a different goroutine.
	Each partition should be of approximately equal size.
	Then the main goroutine should merge the 4 sorted subarrays into one large sorted array.

	The program should prompt the user to input a series of integers.
	Each goroutine which sorts ¼ of the array should print the subarray that it will sort.
	When sorting is complete, the main goroutine should print the entire sorted list.
	********/

	var input string
	fmt.Println("Enter Integers to be sorted seperated by a comma ','. Do not put space in between numbers!!")
	fmt.Scan(&input)

	// 23,67,2,89,324,879,234,65,98,2,6,23,76,-23,67,54,90,-45,-2
	sArr := strings.Split(input, ",")
	iArr := make([]int, 0)

	for _, val := range sArr {
		i, err := strconv.ParseInt(val, 10, 64)
		if err != nil {
			fmt.Println("Found an improper Number in the input >> ", val)
			continue
		}
		iArr = append(iArr, int(i))
	}

	length := len(iArr)
	partSize := (length + 3) / 4 // Round up to ensure all elements are covered

	var wg sync.WaitGroup
	subArrays := make([][]int, 4)

	// Partition the array into 4 subarrays and sort each in a separate goroutine
	for i := 0; i < 4; i++ {
		start := i * partSize
		end := start + partSize
		if end > length {
			end = length
		}
		subArrays[i] = append([]int{}, iArr[start:end]...)
		wg.Add(1)
		go sortSubArray(&wg, subArrays[i], i)
	}

	wg.Wait()

	// Merge the sorted subarrays into one sorted array
	sortedArray := mergeSortedArrays(subArrays...)
	fmt.Println("Final sorted array:", sortedArray)

}

// Function to sort a portion of the array and print it
func sortSubArray(wg *sync.WaitGroup, arr []int, index int) {
	defer wg.Done()
	fmt.Printf("Goroutine %d sorting subarray: %v\n", index+1, arr)
	sort.Ints(arr)
	fmt.Printf("Goroutine %d sorted subarray: %v\n", index+1, arr)
}

func mergeSortedArrays(arrays ...[]int) []int {
	var merged []int
	for len(arrays) > 1 {
		var newArrays [][]int
		for i := 0; i < len(arrays)-1; i += 2 {
			merged = mergeTwoSortedArrays(arrays[i], arrays[i+1])
			newArrays = append(newArrays, merged)
		}
		if len(arrays)%2 == 1 {
			newArrays = append(newArrays, arrays[len(arrays)-1])
		}
		arrays = newArrays
	}
	return arrays[0]
}

func mergeTwoSortedArrays(a, b []int) []int {
	result := make([]int, len(a)+len(b))
	i, j, k := 0, 0, 0
	for i < len(a) && j < len(b) {
		if a[i] < b[j] {
			result[k] = a[i]
			i++
		} else {
			result[k] = b[j]
			j++
		}
		k++
	}
	for i < len(a) {
		result[k] = a[i]
		i++
		k++
	}
	for j < len(b) {
		result[k] = b[j]
		j++
		k++
	}
	return result
}
