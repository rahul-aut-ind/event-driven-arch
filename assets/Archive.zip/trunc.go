package main

import (
	"fmt"
	"strconv"
)

func main() {
	var input string
	fmt.Print("Please enter a number here >> ")
	fmt.Scan(&input)

	num, err := strconv.ParseFloat(input, 64)
	if err != nil {
		fmt.Println("You have entered a non numeric input. Try Again!!")
		return
	}
	fmt.Println("The integer equivalent of your input is ", int(num))

}
