package main

/*********
 * Author: Rahul Upadhyay
 * Peer-graded Assignment: Module 4 Activity
*********/

import (
	"fmt"
	"math/rand"
	"sync"
	"time"
)

type (
	Chopsticks struct {
		sync.Mutex
	}
	Philsopher struct {
		ID     int
		LChops *Chopsticks
		RChops *Chopsticks
		Times  int
	}
	Host struct {
		CurrentDiners int
	}
)

var wg sync.WaitGroup

const (
	MAX_TIMES_EAT      = 3
	MAX_PHILOSOPHERS   = 5
	MAX_CONCURRENT_EAT = 2
)

func (h *Host) serve(p []*Philsopher, wg *sync.WaitGroup) {

	h.CurrentDiners = 0
	// fmt.Println("Host is starting to serve.")
	defer wg.Done()

	for i := 0; i < MAX_PHILOSOPHERS*MAX_TIMES_EAT; i++ {
		if h.CurrentDiners < MAX_CONCURRENT_EAT {
			j := rand.Intn(MAX_PHILOSOPHERS)
			// fmt.Printf("Serving philosopher %d for the %d time\n", j, (p[j].Times + 1))
			if p[j].Times < MAX_TIMES_EAT {
				h.CurrentDiners += 1
				wg.Add(1)
				go p[j].eat(wg, &h.CurrentDiners)

			} else {
				// fmt.Printf("\nPhilosopher %d is done eating %d times\t\tChoosing different Philosopher..\n", j, p[j].Times)
				i--
			}

		} else {
			// fmt.Printf("\n%d philosophers eating concurrently. Trying again\n", h.CurrentDiners)
			i--
		}
	}
}

func (p *Philsopher) eat(wg *sync.WaitGroup, counter *int) {
	defer wg.Done()
	p.LChops.Lock()
	p.RChops.Lock()
	p.Times += 1

	fmt.Println("starting to eat ", p.ID)
	time.Sleep(time.Second)
	fmt.Println("finishing eating ", p.ID)

	p.LChops.Unlock()
	p.RChops.Unlock()
	*counter--
}

func main() {
	/*******
		Implement the dining philosopher’s problem with the following constraints/modifications.
	    There should be 5 philosophers sharing chopsticks,
		with one chopstick between each adjacent pair of philosophers.
	    Each philosopher should eat only 3 times (not in an infinite loop as we did in lecture)
	    The philosophers pick up the chopsticks in any order,
		not lowest-numbered first (which we did in lecture).
	    In order to eat, a philosopher must get permission from a host which executes in its
		own goroutine.
	    The host allows no more than 2 philosophers to eat concurrently.
	    Each philosopher is numbered, 1 through 5.
	    When a philosopher starts eating (after it has obtained necessary locks) it prints
		“starting to eat <number>” on a line by itself, where <number> is the number of the philosopher.
	    When a philosopher finishes eating (before it has released its locks) it prints
		“finishing eating <number>” on a line by itself, where <number> is the number of the philosopher.
		*******/

	CSticks := make([]*Chopsticks, MAX_PHILOSOPHERS)
	for i := 0; i < MAX_PHILOSOPHERS; i++ {
		CSticks[i] = new(Chopsticks)
	}

	philos := make([]*Philsopher, MAX_PHILOSOPHERS)
	for i := 0; i < MAX_PHILOSOPHERS; i++ {
		philos[i] = &Philsopher{
			ID:     i + 1,
			LChops: CSticks[i],
			RChops: CSticks[(i+1)%MAX_PHILOSOPHERS],
			Times:  0,
		}
	}
	host := new(Host)
	wg.Add(1)
	go host.serve(philos, &wg)
	wg.Wait()
	fmt.Println("...")

	for i := 0; i < MAX_PHILOSOPHERS; i++ {
		fmt.Printf("\n Philospher %d ate %d times\n", philos[i].ID, philos[i].Times)
	}
	fmt.Println("-------------- info -------------")
	fmt.Println("uncomment the fmt.Println statements in the code and run it to have a better view of how the objective was achieved")
}
